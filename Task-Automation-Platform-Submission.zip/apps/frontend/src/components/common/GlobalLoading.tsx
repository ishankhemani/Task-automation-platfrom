import { Loader2 } from "lucide-react";

export function GlobalLoading() {
  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center space-y-4">
      <Loader2 className="w-10 h-10 text-primary animate-spin" />
      <p className="text-muted-foreground text-sm animate-pulse">
        Initializing Platform...
      </p>
    </div>
  );
}
