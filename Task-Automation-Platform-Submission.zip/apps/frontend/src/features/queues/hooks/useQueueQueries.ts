import { useQuery } from '@tanstack/react-query';
import { queuesApi } from '../api/queuesApi.js';
import { IQueueStats } from '@task-platform/shared';
import { WorkerNodeStats } from '../api/queuesApi.js';

export function useQueueQueries() {
  const queueStatsQuery = useQuery({
    queryKey: ['queues', 'stats'],
    queryFn: async (): Promise<IQueueStats[]> => {
      const res = await queuesApi.getStats();
      // Unwrap envelope — backend always returns IQueueStats[] here
      return res.data ?? [];
    },
    refetchInterval: 5000,
  });

  const workerStatsQuery = useQuery({
    queryKey: ['queues', 'workers'],
    queryFn: async (): Promise<WorkerNodeStats[]> => {
      const res = await queuesApi.getWorkers();
      // Unwrap envelope — backend always returns WorkerNodeStats[] here
      return res.data ?? [];
    },
    refetchInterval: 10000,
  });

  return {
    // These are always arrays — callers do not need to guard them
    queueStats: queueStatsQuery.data ?? [],
    isQueueLoading: queueStatsQuery.isLoading,
    refetchQueues: queueStatsQuery.refetch,
    workerStats: workerStatsQuery.data ?? [],
    isWorkerLoading: workerStatsQuery.isLoading,
  };
}
