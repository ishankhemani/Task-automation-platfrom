export * from './prisma.js';
