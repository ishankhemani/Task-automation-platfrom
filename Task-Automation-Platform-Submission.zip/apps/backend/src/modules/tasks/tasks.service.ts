import { TasksRepository } from './tasks.repository.js';
import { CreateTaskDTO, UpdateTaskDTO, TasksListQueryDTO } from './tasks.dto.js';
import { TaskStatus, Role } from '@prisma/client';
import { ForbiddenError, NotFoundError, BadRequestError } from '../../errors/index.js';
import { queues } from '../../queues/queueManager.js';
import { QUEUES } from '@task-platform/shared';
import { logger } from '../../utils/index.js';

/** Remove any waiting/delayed BullMQ jobs that belong to a given taskId across all queues */
async function removeBullMQJobForTask(taskId: string): Promise<void> {
  for (const queue of Object.values(queues)) {
    try {
      // Get waiting and delayed jobs (the only ones that can still be cancelled)
      const [waiting, delayed] = await Promise.all([
        queue.getJobs(['waiting']),
        queue.getJobs(['delayed']),
      ]);
      for (const job of [...waiting, ...delayed]) {
        if (job.data?.taskId === taskId) {
          await job.remove();
          logger.info({ taskId, jobId: job.id, queueName: queue.name }, 'Removed BullMQ job on task cancel');
        }
      }
    } catch (err) {
      logger.warn({ taskId, error: (err as Error).message }, 'Failed to remove BullMQ job on cancel — job may have already started');
    }
  }
}

export class TasksService {
  private repository: TasksRepository;

  constructor() {
    this.repository = new TasksRepository();
  }

  async getTasks(query: TasksListQueryDTO, user: { id: string; role: Role }) {
    return this.repository.findManyWithFilters(query, user);
  }

  async getTaskById(id: string, user: { id: string; role: Role }) {
    const task = await this.repository.findByIdWithDetails(id);
    if (!task) {
      throw new NotFoundError('Task not found');
    }

    if (user.role !== Role.ADMIN && task.createdBy !== user.id && task.assignedTo !== user.id) {
      throw new ForbiddenError('You do not have permission to view this task');
    }

    return task;
  }

  async createTask(data: CreateTaskDTO, user: { id: string; role: Role }) {
    // Only ADMIN can assign tasks to other users
    const assignedTo = user.role === Role.ADMIN ? data.assignedTo : undefined;

    const task = await this.repository.createTask({
      ...data,
      assignedTo,
      createdBy: user.id,
    });

    // Record initial status history & creation log
    await Promise.all([
      this.repository.createHistory(task.id, null, TaskStatus.PENDING, user.id, 'Task created'),
      this.repository.createLog(task.id, 'info', `Task "${task.title}" created successfully`, { createdBy: user.id }),
    ]);

    // Dispatch job to BullMQ Queue for asynchronous processing
    let targetQueue = queues[QUEUES.DEFAULT];
    const jobOpts: { delay?: number } = {};

    if (task.scheduledTime) {
      const delayMs = new Date(task.scheduledTime).getTime() - Date.now();
      if (delayMs > 0) {
        jobOpts.delay = delayMs;
        if (queues[QUEUES.SCHEDULED]) {
          targetQueue = queues[QUEUES.SCHEDULED];
        }
      }
    }

    if (targetQueue) {
      await targetQueue
        .add(
          'task:execute',
          {
            taskId: task.id,
            title: task.title,
            payload: { description: task.description, priority: task.priority },
          },
          jobOpts
        )
        .catch((err) => logger.error({ error: err.message }, 'Failed to enqueue task job to BullMQ'));
    }

    return task;
  }

  async updateTask(id: string, data: UpdateTaskDTO, user: { id: string; role: Role }) {
    const existing = await this.repository.findByIdWithDetails(id);
    if (!existing) {
      throw new NotFoundError('Task not found');
    }

    if (user.role !== Role.ADMIN && existing.createdBy !== user.id) {
      throw new ForbiddenError('You do not have permission to update this task');
    }

    const updateData = { ...data };
    if (user.role !== Role.ADMIN) {
      delete updateData.assignedTo;
    }

    const oldStatus = existing.status;
    const updated = await this.repository.updateTask(id, updateData);

    // Track status change if modified
    if (data.status && data.status !== oldStatus) {
      await Promise.all([
        this.repository.createHistory(id, oldStatus, data.status, user.id, `Status updated to ${data.status}`),
        this.repository.createLog(id, 'info', `Task status changed from ${oldStatus} to ${data.status}`),
      ]);
    }

    return updated;
  }

  async deleteTask(id: string, user: { id: string; role: Role }) {
    const existing = await this.repository.findByIdWithDetails(id);
    if (!existing) {
      throw new NotFoundError('Task not found');
    }

    if (user.role !== Role.ADMIN && existing.createdBy !== user.id) {
      throw new ForbiddenError('You do not have permission to delete this task');
    }

    await this.repository.createLog(id, 'warn', `Task soft deleted by user ${user.id}`);
    return this.repository.softDeleteTask(id);
  }

  async cancelTask(id: string, user: { id: string; role: Role }) {
    const existing = await this.repository.findByIdWithDetails(id);
    if (!existing) {
      throw new NotFoundError('Task not found');
    }

    if (user.role !== Role.ADMIN && existing.createdBy !== user.id) {
      throw new ForbiddenError('You do not have permission to cancel this task');
    }

    if (existing.status === TaskStatus.COMPLETED || existing.status === TaskStatus.CANCELLED) {
      throw new BadRequestError(`Cannot cancel task with status ${existing.status}`);
    }

    const updated = await this.repository.updateTask(id, { status: TaskStatus.CANCELLED });
    await Promise.all([
      this.repository.createHistory(id, existing.status, TaskStatus.CANCELLED, user.id, 'Task cancelled by user'),
      this.repository.createLog(id, 'warn', 'Task execution cancelled'),
      // Remove the pending/delayed BullMQ job so the worker never picks it up
      removeBullMQJobForTask(id),
    ]);

    return updated;
  }

  async retryTask(id: string, user: { id: string; role: Role }) {
    const existing = await this.repository.findByIdWithDetails(id);
    if (!existing) {
      throw new NotFoundError('Task not found');
    }

    if (user.role !== Role.ADMIN && existing.createdBy !== user.id) {
      throw new ForbiddenError('You do not have permission to retry this task');
    }

    if (existing.status === TaskStatus.PROCESSING) {
      throw new BadRequestError('Cannot retry a task while it is actively processing');
    }

    const updated = await this.repository.updateTask(id, { status: TaskStatus.PENDING });
    await Promise.all([
      this.repository.createHistory(id, existing.status, TaskStatus.PENDING, user.id, 'Task requeued for retry'),
      this.repository.createLog(id, 'info', 'Task retry requested. Status set back to PENDING'),
    ]);

    if (queues[QUEUES.DEFAULT]) {
      await queues[QUEUES.DEFAULT]
        .add('task:execute', {
          taskId: existing.id,
          title: existing.title,
          payload: { description: existing.description, priority: existing.priority },
        })
        .catch((err) => logger.error({ error: err.message }, 'Failed to re-enqueue retry task job to BullMQ'));
    }

    return updated;
  }

  async duplicateTask(id: string, user: { id: string; role: Role }) {
    const existing = await this.repository.findByIdWithDetails(id);
    if (!existing) {
      throw new NotFoundError('Task not found');
    }

    const duplicated = await this.createTask(
      {
        title: `${existing.title} (Copy)`,
        description: existing.description || undefined,
        priority: existing.priority,
        assignedTo: existing.assignedTo || undefined,
        attachment: existing.attachment || undefined,
      },
      user
    );

    return duplicated;
  }
}
